# Table 3. Internal-layer performance of the rule engine against the NHANES, KNHANES and CHARLS gold standards



| dataset | pairs_tested | rule_pairs_tested | replicated | contradicted | uninformative | precision_rule | precision_rule_ci95 | precision_binary_uninf_as_fp | coverage | phase | methodology |
|---|---|---|---|---|---|---|---|---|---|---|---|
| NHANES |  | 16 | 6 | 0 | 10 | 1.0 | [0.541, 1.0] | 0.375 | 0.889 | confirmatory_R5 | three-state gold + survey svyglm variance (plan §6; R5) + Clopper-Pearson CI |
| KNHANES |  | 15 | 5 | 0 | 10 | 1.0 | [0.478, 1.0] | 0.333 | 0.882 | confirmatory_R5 | three-state gold + survey svyglm variance (plan §6; R5) + Clopper-Pearson CI |
| CHARLS |  | 4 | 0 | 0 | 4 | n/a (0 informative) | [None, None] | 0.0 | 1.0 | confirmatory_R5 | point estimates + declared fallback (no PSU; plan §6); three-state gold, R5 |

